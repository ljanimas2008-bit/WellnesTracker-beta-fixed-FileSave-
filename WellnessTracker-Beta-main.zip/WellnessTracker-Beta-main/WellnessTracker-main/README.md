# Versions

[1.0.0] 11/1/26
- Initial commit.

[1.1.0] 11/17/26
- This was before we changed the UI.

# Suggestions

[1.1.0]
- Give Jymrel Money (Jymrel)
- Put if else sa enterStudentInformation(); para may limit sa name and studentID. (Paul)
- We will create multiple java files for the methods para organized. (Paul)
- Need file saving 
- Need calculation para maunlock ang wellness score

# Fixes and Addition
- Replaced the placeholder error inside `Update()` with `Write()` and matched the capital `U` name. Since the program already remembers all the user's current stats while running, rewriting the file just updates the changed value and keeps everything else untouched.
- Changed the folder path to `"WellnessTracker/Data"` and used `if (!folder.exists())` with `mkdirs()`. If a `Data` folder already exists, it writes the new `.txt` file straight into that existing folder; if there isn't one yet, it automatically creates the `Data` folder first.